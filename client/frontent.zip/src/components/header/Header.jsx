import React, { useState, useEffect, useRef } from 'react';
import { FiMenu, FiSearch, FiChevronDown } from 'react-icons/fi';
import { IoMdClose } from 'react-icons/io';
import { FaBell, FaSearchPlus } from 'react-icons/fa';
import { IoLogoAndroid } from 'react-icons/io';
import { useNavigate } from 'react-router-dom';
import r777 from '../../assets/brand_logo.svg';
import balCoin from '../../assets/balCoin.svg';

import { useDispatch, useSelector } from 'react-redux';
import api from '../../redux/api';
import { wsService } from '../../services/WebsocketService';
import {
  getUser,
  loginUser,
  user_reset,
  changePasswordByFirstLogin,
} from '../../redux/reducer/authReducer';
import ExposureDetails from './ExposureDetails';
import ButtonValues from './ButtonValues';
import Navbar from './Navbar';
function Header({ onMenuToggle, isSidebarOpen }) {
  const [isExposureDetailsOpen, setExposureDetailsOpen] = useState(false);
  const [isButtonValuesOpen, setButtonValuesOpen] = useState(false);

  // New visibility states
  const [showBalance, setShowBalance] = useState(true);
  const [showExposure, setShowExposure] = useState(true);

  const openModal = () => setExposureDetailsOpen(true);
  const closeModal = () => setExposureDetailsOpen(false);
  const openButtonValuesModal = () => setButtonValuesOpen(true);
  const closeButtonValuesModal = () => setButtonValuesOpen(false);
  const navigate = useNavigate();
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const dropdownRef = useRef(null);
  const mobileDropdownRef = useRef(null);
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(getUser());
  }, [dispatch]);

  useEffect(() => {
    if (userInfo?._id) {
      wsService.connect(dispatch, userInfo._id);
    }
  }, [dispatch, userInfo?._id]);

  const logout = async () => {
    try {
      await api.get('/customer/logout', {
        withCredentials: true,
      });
      localStorage.removeItem('auth');
      dispatch(user_reset());
      navigate('/');
    } catch (error) {
      console.log(error?.response?.data || error.message);
    }
  };

  const dropdownItems = [
    { name: 'Account Statement', path: '/account-statement' },
    { name: 'Current Bet', path: '/current-bets' },
    { name: 'Activity Logs', path: '/activity-log' },
    { name: 'Casino Results', path: '/casino-results' },
    { name: 'Set Button Values' },
    { name: 'Change Password', path: '/change-password' },
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      const isOutsideDesktop =
        dropdownRef.current && !dropdownRef.current.contains(event.target);
      const isOutsideMobile =
        mobileDropdownRef.current &&
        !mobileDropdownRef.current.contains(event.target);

      if (isOutsideDesktop && isOutsideMobile) {
        setIsUserDropdownOpen(false);
      }
    };

    if (isUserDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isUserDropdownOpen]);

  return (
    <header className='bg-primary text-primary w-full top-0 fixed left-0'>
      <div className='flex h-[78px] items-center justify-between px-[15px]'>
        <div className='flex h-full items-center'>
          <button
            onClick={onMenuToggle}
            className='text-primary rounded text-2xl hover:opacity-80 lg:hidden'
            aria-label='Toggle menu'
          >
            {isSidebarOpen ? <IoMdClose /> : <FiMenu />}
          </button>
          <img
            src={r777}
            alt='r777'
            className='h-full py-[9px]'
            width={195}
            height={60}
            onClick={() => navigate('/')}
          />
        </div>

        <div className='flex items-center gap-4 text-[12px]'>
          <div className='flex flex-col md:flex-row md:items-center md:gap-4'>
            <div className='flex gap-1'>
              <div className='flex flex-col'>
                <div className='mb-[3px] flex min-w-[100px] justify-center gap-1 rounded-[6px] border-[1px] border-[#72bbef] bg-gradient-to-b from-[#5ecbdd] to-[#146578] px-2 py-[3px] text-[14px]'>
                  <img src={balCoin} alt='' className='w-[18px]' />
                  <span>{userInfo?.avbalance?.toFixed(2)}</span>
                </div>
                <div
                  className='flex min-w-[100px] items-end justify-center gap-1 rounded-[6px] border-[1px] border-[#72bbef] bg-gradient-to-b from-[#5ecbdd] to-[#146578] px-2 py-[3px] text-[14px]'
                  onClick={openModal}
                >
                  <span className='text-[12px] font-semibold'>Exp:</span>{' '}
                  {userInfo?.exposure?.toFixed(2)}
                </div>
              </div>
              <div className='flex min-w-[40px] items-center justify-center gap-1 rounded-[6px] border-[1px] border-[#72bbef] bg-gradient-to-b from-[#5ecbdd] to-[#146578] px-2 text-[14px]'>
                <FaBell size={20} />
              </div>
            </div>

            {/* <div className='flex items-center md:hidden'>
              {showExposure && (
                <span onClick={openModal}>
                  Exp:{' '}
                  <span className='font-bold'>
                    {userInfo?.exposure?.toFixed(2)}
                  </span>
                </span>
              )}
              <div className='relative' ref={mobileDropdownRef}>
                <button
                  onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                  className='flex items-center gap-1 rounded px-2 py-1 hover:opacity-80'
                >
                  <span>{userInfo?.isDemo ? 'Demo' : userInfo?.userName}</span>
                  <FiChevronDown className='text-xs' />
                </button>
                {isUserDropdownOpen && (
                  <div className='absolute right-0 z-50 mt-2 w-45 cursor-pointer rounded bg-white text-[1rem] font-normal text-[#000000] shadow-lg'>
                    {dropdownItems.map((item) => (
                      <span
                        key={item.name}
                        className='block px-4 py-2 hover:bg-gray-100'
                        onClick={() => {
                          if (item.name === 'Set Button Values') {
                            openButtonValuesModal();
                          } else {
                            navigate(item.path);
                          }
                        }}
                      >
                        {item.name}
                      </span>
                    ))}

                    <div
                      className='block border-t border-gray-200 px-4 py-3 hover:bg-gray-100'
                      onClick={logout}
                    >
                      SignOut
                    </div>
                  </div>
                )}
              </div>
            </div> */}

            {/* <div className='relative hidden md:block' ref={dropdownRef}>
              <button
                onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                className='flex items-center gap-1 rounded px-2 py-1 hover:opacity-80'
              >
                <span>{userInfo?.isDemo ? 'Demo' : userInfo?.userName}</span>
                <FiChevronDown className='text-xs' />
              </button>
              {isUserDropdownOpen && (
                <div className='absolute right-0 z-50 mt-2 w-48 cursor-pointer rounded bg-white py-2 text-[1rem] font-normal text-[#000000] shadow-lg'>
                  {dropdownItems.map((item) => (
                    <span
                      key={item.name}
                      className='block px-4 py-2 hover:bg-gray-100'
                      onClick={() => {
                        if (item.name === 'Set Button Values') {
                          openButtonValuesModal();
                        } else {
                          navigate(item.path);
                        }
                      }}
                    >
                      {item.name}
                    </span>
                  ))}
                  <div
                    className='mt-1 border-t px-4 py-2 hover:bg-gray-100'
                    onClick={logout}
                  >
                    SignOut
                  </div>
                </div>
              )}
            </div> */}
          </div>
        </div>
      </div>
        
      <Navbar/>
      {isExposureDetailsOpen && userInfo?.exposure > 0 && (
        <ExposureDetails onClose={closeModal} userId={userInfo?._id} />
      )}
      {isButtonValuesOpen && (
        <ButtonValues onClose={closeButtonValuesModal} userId={userInfo?._id} />
      )}
    </header>
  );
}

export default Header;
