import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { FaFootballBall } from 'react-icons/fa';
import { IoMdTennisball } from 'react-icons/io';
import { GiCricketBat } from 'react-icons/gi';
import aviatorIcon from '../../assets/aviator-icon.svg';

function Navbar() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('home');
  const { matches: cricketMatches } = useSelector((state) => state.cricket);
  const { matches: soccerMatches } = useSelector((state) => state.soccer);
  const { matches: tennisMatches } = useSelector((state) => state.tennis);

  const inplayCounts = {
    cricket: Array.isArray(cricketMatches)
      ? cricketMatches.filter((m) => m.inplay).length
      : 0,
    soccer: Array.isArray(soccerMatches)
      ? soccerMatches.filter((m) => m.inplay).length
      : 0,
    tennis: Array.isArray(tennisMatches)
      ? tennisMatches.filter((m) => m.inplay).length
      : 0,
  };

  const mainNavItems = [
    { id: 'home', label: 'Home', path: '/' },
    { id: 'inplay', label: 'In-Play', path: '/' },
    { id: 'ipl', label: 'IPL 2026', path: '/' },
    { id: 'cricket', label: 'Cricket', icon: GiCricketBat, path: '/cricket' },
    { id: 'soccer', label: 'Soccer', icon: FaFootballBall, path: '/football' },
    { id: 'tennis', label: 'Tennis', icon: IoMdTennisball, path: '/tennis' },
    { id: 'indianPoker', label: 'Indian Poker', path: '/' },
    { id: 'indianPoker2', label: 'Indian Poker2', path: '/' },
    { id: 'rvGames', label: 'RV Games', path: '/' },
    { id: 'aviator', label: 'Aviator', path: '/' },
    { id: 'chickenRoad', label: 'Chicken Road', path: '/' },
    { id: 'ezugi', label: 'Ezugi', path: '/' },
    { id: 'evolution', label: 'Evolution', path: '/' },
    { id: 'liveCasino', label: 'Live Casino', path: '/' },
    { id: 'vivo', label: 'Vivo', path: '/' },
    { id: 'betGames', label: 'Betgames', path: '/' },
    { id: 'casino3', label: 'Casino 3', path: '/' },
  ];

  return (
    <nav className='h-[40px] bg-[#045662] text-[white]'>
      <div className='scrollbar-hide flex h-full'>
        {mainNavItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveNav(item.id);
                if (item.path) {
                  navigate(item.path);
                }
              }}
              className={`relative px-[11px] text-[14px] font-bold hover:bg-[#5ecbdd] ${
                activeNav === item.id &&
                item.id !== 'ezugi' &&
                item.id !== 'ipl'
                  ? 'bg-[#5ecbdd]'
                  : ''
              } ${item.id === 'ezugi' || item.id === 'ipl' ? 'awesome' : ''} `}
            >
              <span className='text-sm font-[700]'>{item.label}</span>

              {(item.id === 'cricket' ||
                item.id === 'tennis' ||
                item.id === 'soccer') && (
                <div className='absolute -top-[6px] right-[3px] z-10 flex h-[12px] min-w-[33px] overflow-hidden rounded-[3px] bg-white text-[10px]'>
                  <span className='flex-1 animate-pulse text-[8px] text-red-500 uppercase'>
                    Live
                  </span>
                  <span className='bg-red-500 px-[3px] text-white'>
                    {inplayCounts[item.id] ?? 0}
                  </span>
                </div>
              )}

              {item.id === 'aviator' && (
                <img
                  src={aviatorIcon}
                  alt=''
                  className='absolute -top-[10px] left-1/2 h-[18px] -translate-x-1/2'
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export default Navbar;
