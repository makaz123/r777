import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { fetchCricketData } from '../../redux/reducer/cricketSlice';
import { fetchSoccerData } from '../../redux/reducer/soccerSlice';
import { fetchTennisData } from '../../redux/reducer/tennisSlice';
import { providerList } from '../../pages/GgrCasino/CasinoData';
import sportsIcon from '../../assets/sports-icons.png';
import inOutIcon from '../../assets/inout-icon-b.svg';
import aviatorIcon from '../../assets/aviator-icon.svg';
import { AiOutlineCloseSquare, AiOutlinePlusSquare } from "react-icons/ai";
import { AiOutlineMinusSquare } from "react-icons/ai";

const providerSpritePositions = {
  indianpoker: '0px -863px',
  indianpoker2: '0px -1742px',
  rvgames: '0px -1706px',
  spribe: '0px -352px',
  chickenroad: '0px -384px',
  ezugi: '0px -1706px',
  evolution: '0px -1706px',
  livecasino: '0px -863px',
  vivo: '0px -1706px',
  betgames: '0px -1706px',
  casino3: '0px -863px',
};

function groupMatchesByLeague(matches) {
  if (!Array.isArray(matches) || matches.length === 0) return [];

  const map = new Map();
  for (const m of matches) {
    const league =
      (m.title && String(m.title).trim()) || 'Other';
    if (!map.has(league)) map.set(league, []);
    map.get(league).push(m);
  }

  return [...map.entries()]
    .map(([league, ms]) => ({ league, matches: ms }))
    .sort((a, b) => a.league.localeCompare(b.league));
}

function Sidebar({ onClose }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [expandedKeys, setExpandedKeys] = useState(() => new Set());

  const { matches: cricketMatches } = useSelector(
    (state) => state.cricket
  );

  const { matches: tennisMatches } = useSelector(
    (state) => state.tennis
  );

  const { matches: soccerMatches } = useSelector(
    (state) => state.soccer
  );

  useEffect(() => {
    dispatch(fetchCricketData());
    dispatch(fetchTennisData());
    dispatch(fetchSoccerData());
  }, [dispatch]);

  const cricketInplayCount = Array.isArray(cricketMatches)
    ? cricketMatches.filter((m) => m.inplay).length
    : 0;

  const soccerInplayCount = Array.isArray(soccerMatches)
    ? soccerMatches.filter((m) => m.inplay).length
    : 0;

  const tennisInplayCount = Array.isArray(tennisMatches)
    ? tennisMatches.filter((m) => m.inplay).length
    : 0;

  const sportsNav = useMemo(
    () => [
      {
        key: 'cricket',
        label: 'Cricket',
        spritePos: '0px -326px',
        matches: cricketMatches,
        betUrl: (m) => `/cricket-bet/${m.game}/${m.id}`,
        badge:
          cricketInplayCount > 0
            ? cricketInplayCount
            : undefined,
      },
      {
        key: 'tennis',
        label: 'Tennis',
        spritePos: '0px -1096px',
        matches: tennisMatches,
        betUrl: (m) => `/tennis-bet/${m.game}/${m.id}`,
        badge:
          tennisInplayCount > 0
            ? tennisInplayCount
            : undefined,
      },
      {
        key: 'soccer',
        label: 'Soccer',
        spritePos: '0px -1026px',
        matches: soccerMatches,
        betUrl: (m) => `/football-bet/${m.game}/${m.id}`,
        badge:
          soccerInplayCount > 0
            ? soccerInplayCount
            : undefined,
      },
    ],
    [
      cricketMatches,
      tennisMatches,
      soccerMatches,
      cricketInplayCount,
      tennisInplayCount,
      soccerInplayCount,
    ]
  );

  const toggleKey = useCallback((key) => {
    setExpandedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const sportKey = (sk) => `nav:sport:${sk}`;
  const leagueKey = (sk, li) => `nav:league:${sk}:${li}`;
  const innerLeagueKey = (sk, li) => `nav:inner:${sk}:${li}`;

  const handleMatchClick = (sport, match) => {
    navigate(sport.betUrl(match));
    if (onClose) onClose();
  };

  const handleProviderClick = (key) => {
    navigate(`/${key}`);

    if (onClose) onClose();
  };

  const ExpandIcon = ({ open }) => (
    <span className='inline-flex h-[18px] w-[18px] flex-shrink-0 items-center justify-center border border-gray-600 bg-white text-[11px] font-bold leading-none text-gray-800'>
      {open ? '−' : '+'}
    </span>
  );

  return (
    <div className='scrollbar-hide sticky top-[118px] h-[calc(100vh-118px)] w-[15%] overflow-y-auto border-r border-gray-200 bg-[#ececec]'>
      <ul className='text-[13px]'>
        {sportsNav.map((sport) => {
          const sk = sportKey(sport.key);
          const leagueOpen = expandedKeys.has(sk);
          const leagues = groupMatchesByLeague(sport.matches);

          return (
            <li
              key={sport.key}
              className='border-b border-gray-300'
            >
              <div
                role='button'
                tabIndex={0}
                className={`flex cursor-pointer items-center gap-2 px-2.5 py-2 text-[#045662] transition-colors hover:bg-[#d4e8ec] ${
                  leagueOpen ? 'bg-[#d8e8eb]' : ''
                }`}
                onClick={() => toggleKey(sk)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleKey(sk);
                  }
                }}
              >
                <span
                  className='inline-block h-6 w-[28px] flex-shrink-0 bg-no-repeat'
                  style={{
                    backgroundImage: `url(${sportsIcon})`,
                    backgroundPosition: sport.spritePos,
                    backgroundSize: '28px auto',
                    backgroundRepeat: 'no-repeat',
                  }}
                />
                <span className='min-w-0 flex-1 font-bold'>
                  {sport.label}
                </span>
              </div>

              {leagueOpen && (
                <ul className='bg-gray-300'>
                  {leagues.map(({ league, matches: lm }, index) => {
                    const ik = innerLeagueKey(sport.key, index);
                    const innerOpen = expandedKeys.has(ik);

                    return (
                      <li
                        key={ik}
                        className='ml-5 mr-2 py-2'
                      >
                        <div
                          role='button'
                          tabIndex={0}
                          className={`flex cursor-pointer items-center gap-2 border-l-2 pl-3  border-gray-500 text-[#045662]`}
                          onClick={() => toggleKey(ik)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              toggleKey(ik);
                            }
                          }}
                        >
                          <span className='min-w-0 flex-1 font-semibold'>
                            {league}
                          </span>
                          {innerOpen ? <AiOutlineMinusSquare /> : <AiOutlinePlusSquare />}
                        </div>

                        {innerOpen && (
                          <ul>
                            {lm.map((m) => (
                              <li
                                key={`${sport.key}-${m.id}-${m.game}`}
                                className='ml-3 py-2'
                                role='link'
                                tabIndex={0}
                                onClick={() => 
                                  handleMatchClick(sport, m)
                                }
                                onKeyDown={(e) => {
                                  if (
                                    e.key === 'Enter' ||
                                    e.key === ' '
                                  ) {
                                    e.preventDefault();
                                    handleMatchClick(sport, m);
                                  }
                                }}
                              >
                                <div className='flex cursor-pointer items-center gap-2 border-l-2 pl-3  border-gray-500 text-[#045662]'>
                                <span className='min-w-0 flex-1 font-semibold'>{m.game || 'Match'}</span>
                                  <AiOutlineCloseSquare />
                                </div>
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </li>
          );
        })}

        {/* PROVIDERS */}
        {providerList.map((p) => (
          <li
            key={p.key}
            className='flex cursor-pointer items-center border-b border-gray-200 gap-2 px-2.5 py-2 transition-colors text-[#045662] hover:bg-[#19a6c5] hover:text-white'
            onClick={() =>
              handleProviderClick(p.key)
            }
          >
            {/* SPRITE ICON */}
            {(p.key !== 'spribe' && p.key !== 'inout') && (
              <span
                className='inline-block h-6 w-6 flex-shrink-0 bg-no-repeat'
                style={{
                  backgroundImage: `url(${sportsIcon})`,
                  backgroundPosition: providerSpritePositions[p.key],
                  backgroundSize: '28px auto',
                  width: '28px',
                  backgroundRepeat: 'no-repeat',
                }}
              />
            )}
            {p.key === 'spribe' && (
              <span className='w-[28px]'><img src={aviatorIcon} alt="" className='w-[24px]' /></span>
            )}
            {p.key === 'inout' && (
              <span className='w-[28px]'><img src={inOutIcon} alt="" className='h-[20px]' /></span>
            )}
            {/* <img src={inOutIcon} alt="" />
            <img src={aviatorIcon} alt="" /> */}
            <span className='text-sm font-bold'>
              {p.label}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;