import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../components/header/Header';
import Navbar from '../components/header/Navbar';
import MobileNav from '../components/header/MobileNav';
import Sidebar from '../components/sidebar/Sidebar';
import Footer from '../components/footer/Footer';
function MainLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  return (
    <div className=''>
      <Header onMenuToggle={toggleSidebar} isSidebarOpen={isSidebarOpen} />
      {/* <div className='hidden lg:block'>
        <Navbar />
      </div> */}
      {/* <div className='block md:hidden'>
        <MobileNav />
      </div> */}
      <div className='flex mt-[118px]'>
        <Sidebar isOpen={isSidebarOpen} onClose={closeSidebar} />
        <main className='scrollbar-hide w-full flex-1 lg:ml-0'>
          <Outlet />
        </main>
      </div>
      {/* <Footer /> */}
    </div>
  );
}

export default MainLayout;
