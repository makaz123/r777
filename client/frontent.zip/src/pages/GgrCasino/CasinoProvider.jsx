import React, { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { casinoData } from './CasinoData';
import aviatorBann from '../../assets/aviator-banner.jpg'
import inOutBann from '../../assets/chickenroad-banner.jpg'

function CasinoProvider() {
  const { provider } = useParams();
  const navigate = useNavigate();
  const providerKey = (provider || '').toLowerCase();

  const games = useMemo(() => {
    const raw = casinoData.providers[providerKey];
    return Array.isArray(raw) ? raw : [];
  }, [providerKey]);


  const handleGameClick = (game) => {
    if (!game?.game_uid) return;
    navigate(
      `/casino-bet/${encodeURIComponent(game.game_name)}/${game.game_uid}`,
      { state: { game, provider: providerKey } }
    );
  };

  if (!casinoData.providers[providerKey]) {
    return (
      <div className='flex h-[calc(100vh-200px)] flex-col items-center justify-center p-6 text-center'>
        <h2 className='text-lg font-semibold text-gray-200'>
          Provider not found
        </h2>
        <p className='mt-2 text-sm text-gray-400'>
          The provider "{provider}" is not available.
        </p>
        <button
          className='mt-4 rounded bg-yellow-500 px-4 py-2 text-sm font-semibold text-black'
          onClick={() => navigate('/')}
        >
          Go Home
        </button>
      </div>
    );
  }

  return (
    <div className='w-full px-2 pb-2'>

      {providerKey === 'spribe' && (
        <img src={aviatorBann} alt="" className="block" />
      )}
      {providerKey === 'inout' && (
        <img src={inOutBann} alt="" className="block" />
      )}

      {games.length === 0 ? (
        <div className='flex h-40 items-center justify-center text-sm text-gray-400'>
          No games found.
        </div>
      ) : (
        <div className='grid grid-cols-3 gap-3 md:grid-cols-6 mt-4'>
          {games.map((game) => (
            <div
              key={`${game.id}-${game.game_uid}`}
              onClick={() => handleGameClick(game)}
              className='cursor-pointer flex flex-col'
            >
              <div className='border-[3px] border-[045662] rounded-md overflow-hidden'>
                <img
                  src={game.icon}
                  alt={game.game_name}
                  loading='lazy'
                    className='w-full object-cover h-[250px] block'
                  onError={(e) => {
                    e.currentTarget.style.opacity = '0.4';
                  }}
                />
              </div>
              <span className='flex py-2 w-full items-center justify-center truncate text-center text-[14px] font-bold'>
                {game.game_name}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default CasinoProvider;
