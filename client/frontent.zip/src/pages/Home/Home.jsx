import React, { useState } from 'react';
import MobileNav from '../../components/header/MobileNav';
import Sports from './sports/Sports';
import OurCasino from './ourcasino/OurCasino';
import { MdSportsCricket } from 'react-icons/md';
import { BiSolidCricketBall } from 'react-icons/bi';
import Cricket from './Cricket';
import Football from './Football';
import Tennis from './Tennis';
import AllCasino from './ourcasino/AllCasino';
import Crash from './crash/Crash';
const tabs = [
  { name: 'Cricket' },
  { name: 'Football' },
  { name: 'Tennis' },
];

function Home() {
  const [selected, setSelected] = useState('SPORTS');
  const [activeTab, setActiveTab] = useState('Cricket');
  return (
    <div>
      <div className='block lg:hidden'>
        <MobileNav selected={selected} setSelected={setSelected} />
      </div>
        <div>
          
        </div>
        <Cricket />
        <Football />
        <Tennis />
    </div>
  );
}

export default Home;
